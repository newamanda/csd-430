//Amanda New
//CSD430
//Module 4: JavaBean
//August 31st, 2025

package beans;

import java.io.Serializable;

public class Books implements Serializable {
	private String title;
	private String author;
	private String releaseDate;
	private String favoriteCharacters;
	private String favoriteParts;
	
	public Books() {}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getReleaseDate() {
		return releaseDate;
	}
	
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	public String getFavoriteCharacters() {
		return favoriteCharacters;
	}
	
	public void setFavoriteCharacters(String favoriteCharacters) {
		this.favoriteCharacters = favoriteCharacters;
	}
	
	public String getFavoriteParts() {
		return favoriteParts;
	}
	
	public void setFavoriteParts (String favoriteParts) {
		this.favoriteParts = favoriteParts;
	}

}
